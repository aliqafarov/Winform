﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            panel1.MouseClick += panel1_Paint;
            panel1.MouseMove += panel1_Paint2;
        }

      
        private void panel1_Paint(object sender, MouseEventArgs e)
        {
            if (ModifierKeys == Keys.Control && e.Button == MouseButtons.Left)
            {
                Close();
            }
            else if (e.Button == MouseButtons.Left)
            {
                MessageBox.Show("X :" +Convert.ToString(e.X) + "\n" + "Y :" + Convert.ToString(e.Y));
                
            }
           
        }

        private void panel1_Paint2(object sender, MouseEventArgs e)
        { 
                textBox1.Text = Convert.ToString(e.X);
                textBox2.Text = Convert.ToString(e.Y);
          
        }
    }
}
