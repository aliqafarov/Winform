﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task2
{
    public partial class Form1 : Form
    {
        private int number;
        public Form1()
        {
            Random random = new Random();
            number = random.Next(0, 2000);
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (number == Convert.ToInt32(textBox1.Text))
            {
                MessageBox.Show("Congurulation !!! You find number");
                Close();
            }
            else if(number> Convert.ToInt32(textBox1.Text)) MessageBox.Show("Your choice is low than number");
            else   MessageBox.Show("Your choice is high than number");
        }
    }
}
