﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            Users = new BindingList<User>();

            listBox1.DataSource = Users;
            listBox1.DisplayMember = "name";

        }

      public static BindingList<User> Users;
      private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();

            this.Hide();
            form2.ShowDialog();
            
            this.Show();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string item = listBox1.GetItemText(listBox1.SelectedItem);

            for (int i = 0; i < Users.Count; i++)
            {
                if(item ==Users[i].name)
                {
                    Form3 form3 = new Form3();

                    this.Hide();
                    form3.ShowDialog();
                    Users.Remove(Users[i]);
                    this.Show();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string item = listBox1.GetItemText(listBox1.SelectedItem);
            for (int i = 0; i < Users.Count; i++)
            {
                if(item == Users[i].name) Users.Remove(Users[i]);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            this.Hide();
            form4.ShowDialog();
            this.Show();
        }
    }
}
