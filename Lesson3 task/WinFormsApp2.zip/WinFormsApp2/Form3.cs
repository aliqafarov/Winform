﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form3 : Form
    {
       public static  User testUser ;
        public Form3()
        {
            InitializeComponent();
            testUser = new User();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox3.Text != "")
            {
                User user = new User();

                user.name = textBox1.Text;
                user.surname = textBox2.Text;
                user.age = textBox3.Text;
                user.mobileNumber = textBox4.Text;
                Form1.Users.Add(user);

                this.Close();
            }
        }
    }
}
