﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp2
{
   public  class User
    {
        public string name { get; set; }
        public string surname;
        public string age;
        public string mobileNumber;
    }
}
