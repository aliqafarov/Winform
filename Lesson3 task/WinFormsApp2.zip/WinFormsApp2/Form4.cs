﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form4 : Form
    {
        public static  int num;
        public BindingList<User> guest;
        public Form4()
        {
            InitializeComponent();
            num = 1;
            label5.Text = Form1.Users[0].name;
            label6.Text = Form1.Users[0].surname;
            label7.Text = Form1.Users[0].age;
            label8.Text = Form1.Users[0].mobileNumber;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(num<Form1.Users.Count)
            {
                label5.Text = Form1.Users[num].name;
                label6.Text = Form1.Users[num].surname;
                label7.Text = Form1.Users[num].age;
                label8.Text = Form1.Users[num].mobileNumber;
                num++;
            }
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
